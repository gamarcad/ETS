pub trait Randomize {
    fn randomize<'a>(&self) -> Self;
}
